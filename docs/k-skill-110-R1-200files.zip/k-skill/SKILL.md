---
name: k-skill
description: 한국 특화 검색·조회·자동화 스킬 110개 모음. 쇼핑 가격비교, 부동산·경매, 교통·예매, 공공·행정·법률, 금융·주식, 날씨·생활, 한국어 글쓰기 등 한국 서비스와 공공데이터를 다루는 요청에 사용한다. 아래 목록에서 맞는 스킬을 찾아 skills 폴더의 해당 파일을 읽고 따른다.
license: MIT
---

# k-skill (110개 스킬 묶음)

요청에 맞는 스킬을 아래 목록에서 고른 뒤 `skills/<스킬 이름>.md`를 읽고 그 지침을 따른다.
각 skills/*.md에는 원본 SKILL.md, instruction.md, references 자료가 한 파일에 합쳐져 있다.

## 쇼핑 · 커머스

- [`coupang-product-search`](skills/coupang-product-search.md) — 쿠팡 Partners API로 상품 검색·로켓배송·가격 후보 비교
- [`naver-shopping-search`](skills/naver-shopping-search.md) — 네이버 쇼핑 BFF로 상품 후보·최저가·판매처 가격비교
- [`danawa-price-search`](skills/danawa-price-search.md) — 다나와 가격비교로 실구매가·카드할인·무이자할부 비교
- [`daiso-product-search`](skills/daiso-product-search.md) — 다이소몰 매장별 상품 재고 조회
- [`ohou-today-deal`](skills/ohou-today-deal.md) — 오늘의집 오늘의딜 특가·할인율·리뷰·링크 조회
- [`bunjang-search`](skills/bunjang-search.md) — 번개장터 검색·상세·찜·채팅·대량수집·AI TOON export
- [`daangn-used-goods-search`](skills/daangn-used-goods-search.md) — 당근 중고거래 키워드·지역 매물 검색/상세

## 부동산 · 경매 · 차량

- [`real-estate-search`](skills/real-estate-search.md) — 아파트/오피스텔/빌라 실거래가·전월세 조회 (MOLIT)
- [`daangn-realty-search`](skills/daangn-realty-search.md) — 당근부동산 지역 기반 매물 검색/상세
- [`gongsijiga-search`](skills/gongsijiga-search.md) — 개별공시지가(원/㎡) 조회 (세금 산정용, 시세 아님)
- [`housing-official-price`](skills/housing-official-price.md) — 공동주택 공시가격 조회
- [`building-register-search`](skills/building-register-search.md) — 건축물대장 표제부 조회 (주소·PNU 기준)
- [`court-auction-notice-search`](skills/court-auction-notice-search.md) — 대법원경매정보 부동산 매각공고·사건 조회
- [`daangn-cars-search`](skills/daangn-cars-search.md) — 당근중고차 지역·가격 조건 차량 검색/상세
- [`iros-registry-automation`](skills/iros-registry-automation.md) — 인터넷등기소 등기사항증명서 발급 준비·브라우저 핸드오프

## 교통 · 예매 · 여행

- [`express-bus-booking`](skills/express-bus-booking.md) — 고속버스(KOBUS) 예매·시간표·좌석·임시선점
- [`intercity-bus-booking`](skills/intercity-bus-booking.md) — 시외버스(Tmoney) 예매·시간표·좌석/요금
- [`railway-timetable`](skills/railway-timetable.md) — Korail 통합 철도 시간표 조회 (KTX 계열, 조회 전용)
- [`flight-ticket-search`](skills/flight-ticket-search.md) — Google Flights 항공권 후보·최저가/평균가 비교
- [`myrealtrip-search`](skills/myrealtrip-search.md) — 마이리얼트립 항공권·숙소·투어/티켓/액티비티 검색
- [`korean-transit-route`](skills/korean-transit-route.md) — 지하철+버스+도보 door-to-door 대중교통 경로 (ODsay)
- [`komsa-ferry-info`](skills/komsa-ferry-info.md) — 연안여객선 운항 일정·선박·항로 정보 (KOMSA MTIS)
- [`highway-traffic-status`](skills/highway-traffic-status.md) — 고속도로 실시간 소통·정체등급·CCTV 메타데이터
- [`foresttrip-vacancy`](skills/foresttrip-vacancy.md) — 국립자연휴양림 숙박·야영 빈자리 조회
- [`subway-lost-property`](skills/subway-lost-property.md) — 지하철 분실물/유실물 조회 안내 (LOST112)

## 공공 · 행정 · 법률

- [`korean-law-search`](skills/korean-law-search.md) — 법령·조문·판례·법령해석·자치법규 검색
- [`assembly-bill-vote-search`](skills/assembly-bill-vote-search.md) — 의안 검색/상세·국회의원 본회의 표결정보
- [`court-payment-order-assistant`](skills/court-payment-order-assistant.md) — 전자소송 지급명령 인터뷰·신청서 초안·입력 핸드오프
- [`corporate-registration-consulting`](skills/corporate-registration-consulting.md) — 주식회사 발기설립 절차·정관 HWP 작성·등록면허세 안내
- [`korean-privacy-terms`](skills/korean-privacy-terms.md) — Next.js 프로젝트에 한국 법령 기반 약관·개인정보처리방침 설치
- [`korean-patent-search`](skills/korean-patent-search.md) — KIPRIS Plus 특허·실용신안 공보 검색
- [`kr-whois-lookup`](skills/kr-whois-lookup.md) — .kr/한국 도메인·IP·AS 번호 공개 등록정보 조회
- [`zipcode-search`](skills/zipcode-search.md) — 우편번호·공식 영문주소 조회
- [`korean-holiday-calendar`](skills/korean-holiday-calendar.md) — 공휴일·국경일·기념일·24절기·잡절 조회 (KASI)
- [`household-waste-info`](skills/household-waste-info.md) — 시군구별 생활쓰레기 배출 요일·시간·장소
- [`gov-overseas-trip-report`](skills/gov-overseas-trip-report.md) — 공무국외출장·국외훈련 보고서 조회 및 원문 사실 확인
- [`sharenuri-facility-search`](skills/sharenuri-facility-search.md) — 공유누리 공공개방자원(회의실·체육·숙소·물품) 검색·예약정보
- [`lh-notice-search`](skills/lh-notice-search.md) — LH 청약(청년/행복/영구/국민/매입/전세임대) 공고
- [`sh-notice-search`](skills/sh-notice-search.md) — SH공사 청약·주택 공고 목록·본문·첨부
- [`donation-place-search`](skills/donation-place-search.md) — 지역별 기부처 조회·추천
- [`religious-facility-search`](skills/religious-facility-search.md) — 근처 교회·성당·사찰 등 종교시설 조회
- [`public-restroom-nearby`](skills/public-restroom-nearby.md) — 근처 개방 화장실 조회

## 조달 · 입찰 · 기업조회

- [`g2b-order-plan-search`](skills/g2b-order-plan-search.md) — 나라장터 물품·공사·용역·외자 발주계획 검색
- [`g2b-sanctioned-supplier`](skills/g2b-sanctioned-supplier.md) — 나라장터 부정당제재업체(입찰참가자격 제한) 조회
- [`nts-business-registration`](skills/nts-business-registration.md) — 국세청 사업자등록 진위확인·상태조회
- [`nts-tax-delinquency`](skills/nts-tax-delinquency.md) — 국세청 고액·상습체납자 명단 조회
- [`fsc-corporate-info`](skills/fsc-corporate-info.md) — 금융위 기업기본정보(대표자·설립일·업종) 조회
- [`national-pension-workplace`](skills/national-pension-workplace.md) — 국민연금 가입 사업장 가입자수·고지금액·취득/상실 추이
- [`biz-health-check`](skills/biz-health-check.md) — 사업자번호 하나로 등록상태·연금·체납·법인개요·제재 통합 점검
- [`localdata-business-status`](skills/localdata-business-status.md) — 인허가 208종 사업장의 영업/휴업/폐업 상태·업력 조회

## 금융 · 투자 · 통계

- [`multi-asset-morning-briefing`](skills/multi-asset-morning-briefing.md) — 글로벌 주식·금리·외환·원자재·변동성과 한국시장 전달 경로 7섹션 브리핑
- [`market-event-impact`](skills/market-event-impact.md) — 정례 발표·비정형 사건의 교차자산 전달경로·시장 해석 정리
- [`korean-bond-search`](skills/korean-bond-search.md) — 한국 채권 발행조건·잔액·CALL/PUT·CB/EB/BW 검색·비교
- [`company-analysis`](skills/company-analysis.md) — 국내·해외 상장기업 공시·실적 대조 6섹션 분석
- [`k-dart`](skills/k-dart.md) — DART 공시검색·기업개황·재무제표·주요사항보고서
- [`korean-stock-search`](skills/korean-stock-search.md) — 상장종목 검색·KRX 기본정보·시세 조회
- [`toss-investment`](skills/toss-investment.md) — 토스증권 Open API 계좌·보유주식·시세·주문조회 (read-only)
- [`bok-ecos-stats`](skills/bok-ecos-stats.md) — 한국은행 ECOS 기준금리·환율·물가·통화량 시계열
- [`kosis-stats`](skills/kosis-stats.md) — KOSIS 국가통계포털 통계표 검색·메타데이터·데이터 조회
- [`kamis-food-price`](skills/kamis-food-price.md) — KAMIS 농수축산물 도소매 가격·기간별 비교
- [`popbill`](skills/popbill.md) — 팝빌 전자세금계산서·현금영수증·문자·팩스·휴폐업 조회
- [`korean-jangbu-for`](skills/korean-jangbu-for.md) — 1인 법인·프리랜서·개인사업자 장부 자동화

## 의료 · 안전 · 환경

- [`emergency-room-beds`](skills/emergency-room-beds.md) — 근처 응급실 위치·실시간 병상 현황
- [`nhis-care-checkup-search`](skills/nhis-care-checkup-search.md) — 건보공단 장기요양기관·건강검진기관 조회
- [`mfds-drug-safety`](skills/mfds-drug-safety.md) — 인터뷰형 의약품 안전 체크 (식약처)
- [`mfds-food-safety`](skills/mfds-food-safety.md) — 인터뷰형 식품 안전 체크 (식품안전나라)
- [`korea-weather`](skills/korea-weather.md) — 기상청 단기예보 기반 한국 날씨 요약
- [`seoul-weather-risk`](skills/seoul-weather-risk.md) — 서울 행정동별 기상 위험 예상 시간대
- [`fine-dust-location`](skills/fine-dust-location.md) — 에어코리아 미세먼지/초미세먼지 지역별 조회
- [`ev-charger-nearby`](skills/ev-charger-nearby.md) — 전기차 충전소 위치·충전기 타입·실시간 상태
- [`ev-subsidy-status`](skills/ev-subsidy-status.md) — 지자체별 전기차 보조금 공고·접수·출고잔여 대수

## 지역 · 장소

- [`kakao-map`](skills/kakao-map.md) — 카카오 장소검색·주소↔좌표 변환·자동차 길찾기
- [`bccard-eatpl-search`](skills/bccard-eatpl-search.md) — 지역·역·동네 기준 맛집·카페·회식 장소 추천
- [`kakao-bar-nearby`](skills/kakao-bar-nearby.md) — 근처 술집 검색
- [`cheap-gas-nearby`](skills/cheap-gas-nearby.md) — 근처 최저가 주유소 조회
- [`parking-lot-search`](skills/parking-lot-search.md) — 근처 주차장·공영주차장 조회
- [`seoul-density`](skills/seoul-density.md) — 서울 주요 121개 핫스팟 실시간 혼잡도·인구 현황

## 채용 · 창업 · 지원사업

- [`job-posting-match`](skills/job-posting-match.md) — 이력서 기반 잡코리아·사람인 공고 검색·적합도 분석
- [`jobkorea-talent-search`](skills/jobkorea-talent-search.md) — 잡코리아 인재 이력서 검색·shortlist (기업회원)
- [`saramin-talent-search`](skills/saramin-talent-search.md) — 사람인 인재풀 후보 검색·shortlist (기업회원)
- [`daangn-jobs-search`](skills/daangn-jobs-search.md) — 당근알바 키워드·지역 알바 공고 검색/상세
- [`government-support-survey`](skills/government-support-survey.md) — K-Startup·기업마당·NIPA·KOCCA·SMTECH 공고 전수조사·적합성 분류
- [`store-longevity-radar`](skills/store-longevity-radar.md) — 상권정보 공개파일로 장수 점포(N년 이상 영업) 선별
- [`korean-scholarship-search`](skills/korean-scholarship-search.md) — 한국 장학금 공고 검색·금액/자격 추출·필터

## 문서 · 한국어 텍스트

- [`hwp`](skills/hwp.md) — kordoc 기반 HWP/HWPX 파싱·JSON 추출·diff·양식 채우기
- [`rhwp-edit`](skills/rhwp-edit.md) — HWP 텍스트 삽입/삭제/치환·표 생성·셀 편집
- [`rhwp-advanced`](skills/rhwp-advanced.md) — HWP 레이아웃 디버깅·IR 덤프·버전 비교·썸네일 추출
- [`korean-spell-check`](skills/korean-spell-check.md) — 한국어 맞춤법 교정 (나라/PNU)
- [`korean-humanizer`](skills/korean-humanizer.md) — AI 티 나는 한국어를 자연스러운 사람 글로 재작성
- [`korean-character-count`](skills/korean-character-count.md) — 한국어 글자/줄/바이트 정확 카운트
- [`korean-slang-writing`](skills/korean-slang-writing.md) — 최신 유행어로 위트있는 한국어 작성
- [`naver-blog-research`](skills/naver-blog-research.md) — 네이버 블로그 검색·본문 전체 읽기·이미지 다운로드

## 미디어 · 뉴스 · 콘텐츠

- [`naver-news-search`](skills/naver-news-search.md) — 네이버 뉴스 검색 (제목·발행시각·링크·요약)
- [`hankookilbo-news`](skills/hankookilbo-news.md) — 한국일보 공식 MCP로 헤드라인·인기·섹션별 기사
- [`geeknews-search`](skills/geeknews-search.md) — 긱뉴스 RSS/Atom 게시물 조회·검색·상세
- [`daishin-report-search`](skills/daishin-report-search.md) — 대신증권 리포트 미러에서 최신 리포트 목록·원문
- [`korean-cinema-search`](skills/korean-cinema-search.md) — CGV·메가박스·롯데시네마 상영작·시간표·잔여석
- [`kopis-performance-search`](skills/kopis-performance-search.md) — KOPIS 공연 목록·상세·공연시설 조회
- [`ticket-availability`](skills/ticket-availability.md) — YES24·인터파크 공연 일정·등급별 잔여석 (조회 전용)
- [`library-book-search`](skills/library-book-search.md) — 한국 도서관 도서·소장정보 검색 (Data4Library)
- [`keris-academic-search`](skills/keris-academic-search.md) — 한국 학위논문·학술논문·연구보고서 검색 (RISS)

## 스포츠 · 엔터 · 운세

- [`korean-marathon-schedule`](skills/korean-marathon-schedule.md) — 마라톤·철인3종 일정·장소·신청 마감일
- [`saju-fortune`](skills/saju-fortune.md) — 사주팔자 연애/재물/직업/건강/궁합 대화형 풀이
- [`naming-house`](skills/naming-house.md) — 생년월일시·성씨 기반 사주 오행·성명학 이름 추천

## 생활 · 기타

- [`delivery-tracking`](skills/delivery-tracking.md) — CJ대한통운·우체국 택배 송장 추적
- [`lotto-results`](skills/lotto-results.md) — 로또 회차별 당첨번호·내 번호 매칭
- [`joseon-sillok-search`](skills/joseon-sillok-search.md) — 조선왕조실록 원문 키워드 검색
- [`korean-heritage-search`](skills/korean-heritage-search.md) — 국가유산 기록·상세·위치·월별 행사 검색

## k-skill 관리

- [`k-skill-setup`](skills/k-skill-setup.md) — 번들 설치·통합 CLI 사용·크리덴셜 해결·런타임 검증
- [`k-skill-cleaner`](skills/k-skill-cleaner.md) — 미사용 스킬 트리거 분석·제거 추천
