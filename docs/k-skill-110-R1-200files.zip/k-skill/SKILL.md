---
name: k-skill
description: 한국 특화 검색·조회·자동화 스킬 110개 모음. 쇼핑 가격비교, 부동산·경매, 교통·예매, 공공·행정·법률, 금융·주식, 날씨·생활, 한국어 글쓰기 등 한국 서비스와 공공데이터를 다루는 요청에 사용한다. 아래 목록에서 맞는 스킬을 찾아 그 폴더의 SKILL.md를 읽고 따른다.
license: MIT
---

# k-skill (110개 스킬 묶음)

요청에 맞는 스킬을 아래 목록에서 고른 뒤 `<스킬 이름>/SKILL.md`를 읽고 그 지침을 따른다.
각 SKILL.md에는 원본 SKILL.md, instruction.md, references 자료가 한 파일에 합쳐져 있다.

## 쇼핑 · 커머스

- [`coupang-product-search`](coupang-product-search/SKILL.md) — 쿠팡 Partners API로 상품 검색·로켓배송·가격 후보 비교
- [`naver-shopping-search`](naver-shopping-search/SKILL.md) — 네이버 쇼핑 BFF로 상품 후보·최저가·판매처 가격비교
- [`danawa-price-search`](danawa-price-search/SKILL.md) — 다나와 가격비교로 실구매가·카드할인·무이자할부 비교
- [`daiso-product-search`](daiso-product-search/SKILL.md) — 다이소몰 매장별 상품 재고 조회
- [`ohou-today-deal`](ohou-today-deal/SKILL.md) — 오늘의집 오늘의딜 특가·할인율·리뷰·링크 조회
- [`bunjang-search`](bunjang-search/SKILL.md) — 번개장터 검색·상세·찜·채팅·대량수집·AI TOON export
- [`daangn-used-goods-search`](daangn-used-goods-search/SKILL.md) — 당근 중고거래 키워드·지역 매물 검색/상세

## 부동산 · 경매 · 차량

- [`real-estate-search`](real-estate-search/SKILL.md) — 아파트/오피스텔/빌라 실거래가·전월세 조회 (MOLIT)
- [`daangn-realty-search`](daangn-realty-search/SKILL.md) — 당근부동산 지역 기반 매물 검색/상세
- [`gongsijiga-search`](gongsijiga-search/SKILL.md) — 개별공시지가(원/㎡) 조회 (세금 산정용, 시세 아님)
- [`housing-official-price`](housing-official-price/SKILL.md) — 공동주택 공시가격 조회
- [`building-register-search`](building-register-search/SKILL.md) — 건축물대장 표제부 조회 (주소·PNU 기준)
- [`court-auction-notice-search`](court-auction-notice-search/SKILL.md) — 대법원경매정보 부동산 매각공고·사건 조회
- [`daangn-cars-search`](daangn-cars-search/SKILL.md) — 당근중고차 지역·가격 조건 차량 검색/상세
- [`iros-registry-automation`](iros-registry-automation/SKILL.md) — 인터넷등기소 등기사항증명서 발급 준비·브라우저 핸드오프

## 교통 · 예매 · 여행

- [`express-bus-booking`](express-bus-booking/SKILL.md) — 고속버스(KOBUS) 예매·시간표·좌석·임시선점
- [`intercity-bus-booking`](intercity-bus-booking/SKILL.md) — 시외버스(Tmoney) 예매·시간표·좌석/요금
- [`railway-timetable`](railway-timetable/SKILL.md) — Korail 통합 철도 시간표 조회 (KTX 계열, 조회 전용)
- [`flight-ticket-search`](flight-ticket-search/SKILL.md) — Google Flights 항공권 후보·최저가/평균가 비교
- [`myrealtrip-search`](myrealtrip-search/SKILL.md) — 마이리얼트립 항공권·숙소·투어/티켓/액티비티 검색
- [`korean-transit-route`](korean-transit-route/SKILL.md) — 지하철+버스+도보 door-to-door 대중교통 경로 (ODsay)
- [`komsa-ferry-info`](komsa-ferry-info/SKILL.md) — 연안여객선 운항 일정·선박·항로 정보 (KOMSA MTIS)
- [`highway-traffic-status`](highway-traffic-status/SKILL.md) — 고속도로 실시간 소통·정체등급·CCTV 메타데이터
- [`foresttrip-vacancy`](foresttrip-vacancy/SKILL.md) — 국립자연휴양림 숙박·야영 빈자리 조회
- [`subway-lost-property`](subway-lost-property/SKILL.md) — 지하철 분실물/유실물 조회 안내 (LOST112)

## 공공 · 행정 · 법률

- [`korean-law-search`](korean-law-search/SKILL.md) — 법령·조문·판례·법령해석·자치법규 검색
- [`assembly-bill-vote-search`](assembly-bill-vote-search/SKILL.md) — 의안 검색/상세·국회의원 본회의 표결정보
- [`court-payment-order-assistant`](court-payment-order-assistant/SKILL.md) — 전자소송 지급명령 인터뷰·신청서 초안·입력 핸드오프
- [`corporate-registration-consulting`](corporate-registration-consulting/SKILL.md) — 주식회사 발기설립 절차·정관 HWP 작성·등록면허세 안내
- [`korean-privacy-terms`](korean-privacy-terms/SKILL.md) — Next.js 프로젝트에 한국 법령 기반 약관·개인정보처리방침 설치
- [`korean-patent-search`](korean-patent-search/SKILL.md) — KIPRIS Plus 특허·실용신안 공보 검색
- [`kr-whois-lookup`](kr-whois-lookup/SKILL.md) — .kr/한국 도메인·IP·AS 번호 공개 등록정보 조회
- [`zipcode-search`](zipcode-search/SKILL.md) — 우편번호·공식 영문주소 조회
- [`korean-holiday-calendar`](korean-holiday-calendar/SKILL.md) — 공휴일·국경일·기념일·24절기·잡절 조회 (KASI)
- [`household-waste-info`](household-waste-info/SKILL.md) — 시군구별 생활쓰레기 배출 요일·시간·장소
- [`gov-overseas-trip-report`](gov-overseas-trip-report/SKILL.md) — 공무국외출장·국외훈련 보고서 조회 및 원문 사실 확인
- [`sharenuri-facility-search`](sharenuri-facility-search/SKILL.md) — 공유누리 공공개방자원(회의실·체육·숙소·물품) 검색·예약정보
- [`lh-notice-search`](lh-notice-search/SKILL.md) — LH 청약(청년/행복/영구/국민/매입/전세임대) 공고
- [`sh-notice-search`](sh-notice-search/SKILL.md) — SH공사 청약·주택 공고 목록·본문·첨부
- [`donation-place-search`](donation-place-search/SKILL.md) — 지역별 기부처 조회·추천
- [`religious-facility-search`](religious-facility-search/SKILL.md) — 근처 교회·성당·사찰 등 종교시설 조회
- [`public-restroom-nearby`](public-restroom-nearby/SKILL.md) — 근처 개방 화장실 조회

## 조달 · 입찰 · 기업조회

- [`g2b-order-plan-search`](g2b-order-plan-search/SKILL.md) — 나라장터 물품·공사·용역·외자 발주계획 검색
- [`g2b-sanctioned-supplier`](g2b-sanctioned-supplier/SKILL.md) — 나라장터 부정당제재업체(입찰참가자격 제한) 조회
- [`nts-business-registration`](nts-business-registration/SKILL.md) — 국세청 사업자등록 진위확인·상태조회
- [`nts-tax-delinquency`](nts-tax-delinquency/SKILL.md) — 국세청 고액·상습체납자 명단 조회
- [`fsc-corporate-info`](fsc-corporate-info/SKILL.md) — 금융위 기업기본정보(대표자·설립일·업종) 조회
- [`national-pension-workplace`](national-pension-workplace/SKILL.md) — 국민연금 가입 사업장 가입자수·고지금액·취득/상실 추이
- [`biz-health-check`](biz-health-check/SKILL.md) — 사업자번호 하나로 등록상태·연금·체납·법인개요·제재 통합 점검
- [`localdata-business-status`](localdata-business-status/SKILL.md) — 인허가 208종 사업장의 영업/휴업/폐업 상태·업력 조회

## 금융 · 투자 · 통계

- [`multi-asset-morning-briefing`](multi-asset-morning-briefing/SKILL.md) — 글로벌 주식·금리·외환·원자재·변동성과 한국시장 전달 경로 7섹션 브리핑
- [`market-event-impact`](market-event-impact/SKILL.md) — 정례 발표·비정형 사건의 교차자산 전달경로·시장 해석 정리
- [`korean-bond-search`](korean-bond-search/SKILL.md) — 한국 채권 발행조건·잔액·CALL/PUT·CB/EB/BW 검색·비교
- [`company-analysis`](company-analysis/SKILL.md) — 국내·해외 상장기업 공시·실적 대조 6섹션 분석
- [`k-dart`](k-dart/SKILL.md) — DART 공시검색·기업개황·재무제표·주요사항보고서
- [`korean-stock-search`](korean-stock-search/SKILL.md) — 상장종목 검색·KRX 기본정보·시세 조회
- [`toss-investment`](toss-investment/SKILL.md) — 토스증권 Open API 계좌·보유주식·시세·주문조회 (read-only)
- [`bok-ecos-stats`](bok-ecos-stats/SKILL.md) — 한국은행 ECOS 기준금리·환율·물가·통화량 시계열
- [`kosis-stats`](kosis-stats/SKILL.md) — KOSIS 국가통계포털 통계표 검색·메타데이터·데이터 조회
- [`kamis-food-price`](kamis-food-price/SKILL.md) — KAMIS 농수축산물 도소매 가격·기간별 비교
- [`popbill`](popbill/SKILL.md) — 팝빌 전자세금계산서·현금영수증·문자·팩스·휴폐업 조회
- [`korean-jangbu-for`](korean-jangbu-for/SKILL.md) — 1인 법인·프리랜서·개인사업자 장부 자동화

## 의료 · 안전 · 환경

- [`emergency-room-beds`](emergency-room-beds/SKILL.md) — 근처 응급실 위치·실시간 병상 현황
- [`nhis-care-checkup-search`](nhis-care-checkup-search/SKILL.md) — 건보공단 장기요양기관·건강검진기관 조회
- [`mfds-drug-safety`](mfds-drug-safety/SKILL.md) — 인터뷰형 의약품 안전 체크 (식약처)
- [`mfds-food-safety`](mfds-food-safety/SKILL.md) — 인터뷰형 식품 안전 체크 (식품안전나라)
- [`korea-weather`](korea-weather/SKILL.md) — 기상청 단기예보 기반 한국 날씨 요약
- [`seoul-weather-risk`](seoul-weather-risk/SKILL.md) — 서울 행정동별 기상 위험 예상 시간대
- [`fine-dust-location`](fine-dust-location/SKILL.md) — 에어코리아 미세먼지/초미세먼지 지역별 조회
- [`ev-charger-nearby`](ev-charger-nearby/SKILL.md) — 전기차 충전소 위치·충전기 타입·실시간 상태
- [`ev-subsidy-status`](ev-subsidy-status/SKILL.md) — 지자체별 전기차 보조금 공고·접수·출고잔여 대수

## 지역 · 장소

- [`kakao-map`](kakao-map/SKILL.md) — 카카오 장소검색·주소↔좌표 변환·자동차 길찾기
- [`bccard-eatpl-search`](bccard-eatpl-search/SKILL.md) — 지역·역·동네 기준 맛집·카페·회식 장소 추천
- [`kakao-bar-nearby`](kakao-bar-nearby/SKILL.md) — 근처 술집 검색
- [`cheap-gas-nearby`](cheap-gas-nearby/SKILL.md) — 근처 최저가 주유소 조회
- [`parking-lot-search`](parking-lot-search/SKILL.md) — 근처 주차장·공영주차장 조회
- [`seoul-density`](seoul-density/SKILL.md) — 서울 주요 121개 핫스팟 실시간 혼잡도·인구 현황

## 채용 · 창업 · 지원사업

- [`job-posting-match`](job-posting-match/SKILL.md) — 이력서 기반 잡코리아·사람인 공고 검색·적합도 분석
- [`jobkorea-talent-search`](jobkorea-talent-search/SKILL.md) — 잡코리아 인재 이력서 검색·shortlist (기업회원)
- [`saramin-talent-search`](saramin-talent-search/SKILL.md) — 사람인 인재풀 후보 검색·shortlist (기업회원)
- [`daangn-jobs-search`](daangn-jobs-search/SKILL.md) — 당근알바 키워드·지역 알바 공고 검색/상세
- [`government-support-survey`](government-support-survey/SKILL.md) — K-Startup·기업마당·NIPA·KOCCA·SMTECH 공고 전수조사·적합성 분류
- [`store-longevity-radar`](store-longevity-radar/SKILL.md) — 상권정보 공개파일로 장수 점포(N년 이상 영업) 선별
- [`korean-scholarship-search`](korean-scholarship-search/SKILL.md) — 한국 장학금 공고 검색·금액/자격 추출·필터

## 문서 · 한국어 텍스트

- [`hwp`](hwp/SKILL.md) — kordoc 기반 HWP/HWPX 파싱·JSON 추출·diff·양식 채우기
- [`rhwp-edit`](rhwp-edit/SKILL.md) — HWP 텍스트 삽입/삭제/치환·표 생성·셀 편집
- [`rhwp-advanced`](rhwp-advanced/SKILL.md) — HWP 레이아웃 디버깅·IR 덤프·버전 비교·썸네일 추출
- [`korean-spell-check`](korean-spell-check/SKILL.md) — 한국어 맞춤법 교정 (나라/PNU)
- [`korean-humanizer`](korean-humanizer/SKILL.md) — AI 티 나는 한국어를 자연스러운 사람 글로 재작성
- [`korean-character-count`](korean-character-count/SKILL.md) — 한국어 글자/줄/바이트 정확 카운트
- [`korean-slang-writing`](korean-slang-writing/SKILL.md) — 최신 유행어로 위트있는 한국어 작성
- [`naver-blog-research`](naver-blog-research/SKILL.md) — 네이버 블로그 검색·본문 전체 읽기·이미지 다운로드

## 미디어 · 뉴스 · 콘텐츠

- [`naver-news-search`](naver-news-search/SKILL.md) — 네이버 뉴스 검색 (제목·발행시각·링크·요약)
- [`hankookilbo-news`](hankookilbo-news/SKILL.md) — 한국일보 공식 MCP로 헤드라인·인기·섹션별 기사
- [`geeknews-search`](geeknews-search/SKILL.md) — 긱뉴스 RSS/Atom 게시물 조회·검색·상세
- [`daishin-report-search`](daishin-report-search/SKILL.md) — 대신증권 리포트 미러에서 최신 리포트 목록·원문
- [`korean-cinema-search`](korean-cinema-search/SKILL.md) — CGV·메가박스·롯데시네마 상영작·시간표·잔여석
- [`kopis-performance-search`](kopis-performance-search/SKILL.md) — KOPIS 공연 목록·상세·공연시설 조회
- [`ticket-availability`](ticket-availability/SKILL.md) — YES24·인터파크 공연 일정·등급별 잔여석 (조회 전용)
- [`library-book-search`](library-book-search/SKILL.md) — 한국 도서관 도서·소장정보 검색 (Data4Library)
- [`keris-academic-search`](keris-academic-search/SKILL.md) — 한국 학위논문·학술논문·연구보고서 검색 (RISS)

## 스포츠 · 엔터 · 운세

- [`korean-marathon-schedule`](korean-marathon-schedule/SKILL.md) — 마라톤·철인3종 일정·장소·신청 마감일
- [`saju-fortune`](saju-fortune/SKILL.md) — 사주팔자 연애/재물/직업/건강/궁합 대화형 풀이
- [`naming-house`](naming-house/SKILL.md) — 생년월일시·성씨 기반 사주 오행·성명학 이름 추천

## 생활 · 기타

- [`delivery-tracking`](delivery-tracking/SKILL.md) — CJ대한통운·우체국 택배 송장 추적
- [`lotto-results`](lotto-results/SKILL.md) — 로또 회차별 당첨번호·내 번호 매칭
- [`joseon-sillok-search`](joseon-sillok-search/SKILL.md) — 조선왕조실록 원문 키워드 검색
- [`korean-heritage-search`](korean-heritage-search/SKILL.md) — 국가유산 기록·상세·위치·월별 행사 검색

## k-skill 관리

- [`k-skill-setup`](k-skill-setup/SKILL.md) — 번들 설치·통합 CLI 사용·크리덴셜 해결·런타임 검증
- [`k-skill-cleaner`](k-skill-cleaner/SKILL.md) — 미사용 스킬 트리거 분석·제거 추천
