# Runtime Action Audit

top-level `SKILL.md` 전체를 돌쇠 우선 실행 계약으로 전수 검토한 결과다. 이 표는 스킬 선택/분류용이며 실제 portable 계약은 각 `SKILL.md`의 `## Runtime contract (required)` 블록이 담당한다.

## Mode definitions

- **commerce**: 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제
- **booking**: 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제
- **submission**: 공식 폼·첨부 준비 → `clarify` 후 제출/지원/결제/취소
- **recruiting**: 기업 인재검색 → shortlist → 유료 열람/제안 직전 `clarify`
- **account**: 지원되는 계정 작업 수행 → 비가역 변경 직전 `clarify`
- **legal**: 공식 법률·정부 표면의 로그인/인증/서류 준비를 진행하고 `clarify` 후 제출·입찰·수수료 결제
- **operations**: k-skill 설치·업데이트·복구·런타임 연결을 실제 적용하고 검증
- **local**: 요청 산출물을 로컬에서 실제 생성·변환·정리
- **lookup**: 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결

## Complete catalog

| Skill | Mode | Dolshoi completion target |
| --- | --- | --- |
| `animal-pharmacy-search` | `lookup` | 지역별 동물약국·제품·최근 6개월 구매 이력 기반 취급 약국 조회 완료 |
| `assembly-bill-vote-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `bccard-eatpl-search` | `lookup` | 요청한 장소의 맛집·음식점·카페와 상세 링크 조회 완료 |
| `biz-health-check` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `bok-ecos-stats` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `building-register-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `bunjang-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `cheap-gas-nearby` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `company-analysis` | `lookup` | 공개 공시·실적발표를 대조해 3대 재무제표와 주가를 포함한 6개 섹션의 채팅 분석 완료 |
| `consumer-price-safety-search` | `lookup` | 공식 소비자 가격·리콜 표면의 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `corporate-registration-consulting` | `legal` | 공식 법률 표면에서 로그인·서류 준비를 진행하고 `clarify` 후 허용된 제출·수수료 결제 |
| `coupang-product-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `court-auction-notice-search` | `legal` | 공식 법원 표면에서 로그인·물건 검토·입찰 준비를 진행하고 `clarify` 후 허용된 법적 액션 |
| `court-payment-order-assistant` | `legal` | 공식 전자소송 표면에서 로그인·서류 준비를 진행하고 `clarify` 후 허용된 제출·수수료 결제 |
| `d2b-notice-search` | `legal` | 공식 조달 표면에서 로그인·공고/서류 준비를 진행하고 `clarify` 후 허용된 제출 |
| `daangn-cars-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `daangn-jobs-search` | `submission` | 공식 계정 표면에서 지원서를 준비하고 `clarify` 후 제출 |
| `daangn-realty-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `daangn-used-goods-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `daishin-report-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `daiso-product-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `danawa-price-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `delivery-tracking` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `donation-place-search` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `emergency-room-beds` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `ev-charger-nearby` | `lookup` | 충전소 위치·충전기 유형·현재 상태 조회 완료 |
| `ev-subsidy-status` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `express-bus-booking` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `fine-dust-location` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `flight-ticket-search` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `foresttrip-vacancy` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `fsc-corporate-info` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `g2b-order-plan-search` | `legal` | 공식 조달 표면에서 로그인·공고/서류 준비를 진행하고 `clarify` 후 허용된 제출 |
| `g2b-sanctioned-supplier` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `geeknews-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `gongsijiga-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `gov-overseas-trip-report` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `government-bond-analysis` | `lookup` | 한국·미국 국채 금리의 관측일·만기·단위를 검증해 변화와 공식 확인 일정을 출처와 함께 정리 |
| `government-support-survey` | `submission` | 정부지원 공고 전수조사와 신청 요건 확인 후 공식 신청서·첨부를 준비하고 `clarify` 후 제출 |
| `han-river-water-level` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `hankookilbo-news` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `highway-traffic-status` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `hola-poke-yeoksam` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `household-waste-info` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `housing-official-price` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `hwp` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `intercity-bus-booking` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `iros-registry-automation` | `legal` | 공식 등기 표면에서 로그인·서류 준비를 진행하고 `clarify` 후 허용된 신청·수수료 결제 |
| `job-posting-match` | `lookup` | 공개 채용공고를 검색하고 이력서 기반 적합도·지원 전략을 정리 |
| `jobkorea-talent-search` | `recruiting` | 후보 shortlist를 만들고 `clarify` 후 유료 열람·연락처 공개·제안 전송 |
| `joseon-sillok-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `k-dart` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `k-schoollunch-menu` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `k-skill-cleaner` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `k-skill-setup` | `operations` | 설치·업데이트·복구·브라우저/프록시/vault 연결을 적용하고 검증 |
| `kakao-bar-nearby` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `kakao-map` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `kakaotalk-mac` | `lookup` | 로컬 카카오톡 아카이브 동기화·검색·chunk 조회 완료 |
| `kbl-results` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `kbo-results` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `keris-academic-search` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `kleague-results` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `kopis-performance-search` | `lookup` | KOPIS 공연·시설 목록과 상세 조회 완료 |
| `korea-weather` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `korean-bond-search` | `lookup` | 채권 후보를 식별하고 출처·확인시각이 보존된 발행조건과 옵션을 비교 |
| `korean-character-count` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `korean-cinema-search` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `korean-heritage-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `korean-holiday-calendar` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `kamis-food-price` | `lookup` | KAMIS 농수축산물 도소매 가격과 비교값 조회 완료 |
| `korean-humanizer` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `korean-jangbu-for` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `korean-law-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `korean-marathon-schedule` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `korean-middle-korean` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `korean-patent-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `korean-privacy-terms` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `korean-scholarship-search` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `korean-slang-writing` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `korean-spell-check` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `korean-stock-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `korean-transit-route` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `kosis-stats` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `kr-whois-lookup` | `lookup` | 공개 WHOIS 등록정보 조회 완료 |
| `komsa-ferry-info` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `kstartup-search` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `lck-analytics` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `lh-notice-search` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `library-book-search` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `localdata-business-status` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `lotto-results` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `market-event-impact` | `lookup` | 사건의 공식 발표·당시 보도·확정 가격을 대조하고, 교차자산 영향과 근거등급을 한국어로 설명 |
| `market-kurly-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `mfds-drug-safety` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `mfds-food-safety` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `myrealtrip-search` | `booking` | 공식 일정/좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `mofa-travel-safety` | `lookup` | 외교부 국가·지역별 공식 여행경보 조회 완료 |
| `multi-asset-morning-briefing` | `lookup` | 공개 시장 데이터를 관측일·출처와 함께 조회하고, 미확인·지연 수치는 본문에서 제외 |
| `naming-house` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `national-pension-workplace` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `naver-ad-performance` | `account` | 지원되는 계정 작업 수행 → 비가역 변경 직전 `clarify` |
| `naver-blog-research` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `naver-news-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `naver-shopping-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `nhis-care-checkup-search` | `lookup` | 장기요양기관·건강검진기관 후보와 공개 정보를 조회 |
| `nts-business-registration` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `nts-tax-delinquency` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `ohou-today-deal` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `olive-young-search` | `commerce` | 공식 상품 선택 → 장바구니/checkout 준비 → `clarify` 후 주문·결제 |
| `parking-lot-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `popbill` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `public-restroom-nearby` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `real-estate-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `religious-facility-search` | `lookup` | 지역 기준 교회·성당·사찰 조회를 완료하고, 별도 후속 행동 요청 시 각 시설 공식 홈페이지·연락처로 연결 |
| `rhwp-advanced` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `rhwp-edit` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `s2b-notice-search` | `legal` | 공식 학교장터 표면에서 로그인·공고/서류 준비를 진행하고 `clarify` 후 허용된 제출 |
| `saju-fortune` | `local` | 요청 산출물을 로컬에서 실제 생성·변환·정리 |
| `saramin-talent-search` | `recruiting` | 후보 shortlist를 만들고 `clarify` 후 유료 열람·연락처 공개·제안 전송 |
| `seoul-bike` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `seoul-density` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `seoul-subway-arrival` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `seoul-weather-risk` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `sh-notice-search` | `submission` | 공식 폼·첨부 준비 → `clarify` 후 제출/결제/취소 |
| `sharenuri-facility-search` | `lookup` | 공유누리 공개 통합검색·상세 조회를 완료하고, 예약 등 후속 행동은 공식 상세 화면으로 연결 |
| `railway-timetable` | `lookup` | 코레일 공식 통합 공개 XLSX로 KTX 계열 시간표를 조회; 예약·결제·취소 없음 |
| `store-longevity-radar` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |
| `subway-lost-property` | `lookup` | LOST112·운영기관 공식 표면의 검색 조건과 결과를 정리 |
| `ticket-availability` | `booking` | 공식 일정·좌석 선택 → 예약·선점 → `clarify` 후 필요한 결제 |
| `toss-investment` | `account` | 지원되는 계정 작업 수행 → 비가역 변경 직전 `clarify` |
| `zipcode-search` | `lookup` | 요청한 조회를 완료하고, 별도 후속 행동 요청 시 지원되는 공식 표면으로 연결 |

## Commerce capability gaps

`commerce`는 검색 결과나 딥링크에서 끝나는 유형이 아니다. 돌쇠에서는 공식
상품/매물 상태를 재확인하고, 필요한 경우 CloakBrowser와 vault-backed login을
사용해 장바구니·문의·예약·checkout을 준비하며, 결제·계약·메시지 전송 직전
`clarify` 승인을 받아야 한다.

현재 이 실행 경로가 완성되지 않은 스킬은 다음 이슈에서 추적한다.

| Skill | Expansion issue |
|---|---|
| `daangn-cars-search` | [#450](https://github.com/NomaDamas/k-skill/issues/450) |
| `daangn-realty-search` | [#453](https://github.com/NomaDamas/k-skill/issues/453) |
| `daangn-used-goods-search` | [#445](https://github.com/NomaDamas/k-skill/issues/445) |
| `daiso-product-search` | [#452](https://github.com/NomaDamas/k-skill/issues/452) |
| `danawa-price-search` | [#446](https://github.com/NomaDamas/k-skill/issues/446) |
| `hola-poke-yeoksam` | [#447](https://github.com/NomaDamas/k-skill/issues/447) |
| `market-kurly-search` | [#454](https://github.com/NomaDamas/k-skill/issues/454) |
| `ohou-today-deal` | [#448](https://github.com/NomaDamas/k-skill/issues/448) |
| `olive-young-search` | [#449](https://github.com/NomaDamas/k-skill/issues/449) |

이슈가 완료되기 전에는 해당 스킬의 현재 조회/링크 기능을 실제 구매 완료로
과장하지 않는다. 공식 표면이 후속 거래를 지원하지 않는 것으로 확인되면
`commerce` 대신 `lookup`, `submission`, 또는 다른 실제 capability profile로
재분류한다.

## Maintenance

- 새 top-level skill을 추가하면 이 표와 `scripts/skill-docs.test.js`의 전체 개수/액션 목록을 함께 갱신한다.
- mode가 `lookup`이어도 사용자가 downstream action을 명시하면 portable runtime contract에 따라 공식 표면이 지원하는 범위까지 이어간다.
- `legal`은 단순 read-only가 아니다. 공식 표면의 로그인·인증·서류 준비·prefill을 진행하고, 법적 효과 직전 `clarify` 승인을 받는다. CAPTCHA나 보안 통제는 우회하지 않는다.
