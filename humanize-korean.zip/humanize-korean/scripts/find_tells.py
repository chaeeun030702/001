#!/usr/bin/env python3
"""Scan Korean text for common AI-writing tells.

Usage:
    python find_tells.py draft.md
    cat draft.md | python find_tells.py

Reports line numbers and counts for cliche phrases, translationese,
double passives and hedges. Candidates only -- a hit is not a verdict,
and clean output does not mean the text reads naturally.
"""

import re
import sys
from collections import defaultdict

PATTERNS = [
    # (category, regex, note)
    ("과장 수식어", r"혁신적|획기적|압도적|눈부신|폭발적|필수적|핵심적|매우 중요|놀라운|차원이 다른|진정한", "대개 삭제"),
    ("공허한 명사", r"효율성|극대화|고도화|활성화|유기적|시너지|인사이트|니즈|솔루션|패러다임", "구체어로 교체"),
    ("정형 문형", r"단순히 .{1,20}(가|이) 아니라|뿐만 아니라|중요한 (것|점)은|라고 할 수 있|인 셈|볼 수 있습니다", "재작성"),
    ("번역체", r"우리는|당신의|를 통해|을 통해|에 있어서|와 관련하여|과 관련하여|의 경우에는|것이 가능|중 하나(입니다|이다)|함에 따라", "직역 흔적"),
    ("이중 피동", r"되어지|보여집니다|불려집니다|쓰여집니다|잊혀집니다", "비문"),
    ("완충 표현", r"할 수 있습니다|일 수 있습니다|경우에 따라|일반적으로|대체로|인 편입니다", "단정 검토"),
    ("맺음 클리셰", r"결론적으로|정리하(면|자면)|종합해 보면|요약하자면|도움이 되셨|참고하시기 바랍니다|알아보겠습니다|알아보았습니다|살펴보겠습니다", "삭제 검토"),
    ("서론 클리셰", r"좋은 질문|궁금하셨|이야기해 보려|함께 들어가", "삭제"),
    ("지시어 시작", r"^\s*(이는|이것은|그것은|이처럼|이렇듯)", "지시 대상 복원"),
    ("접속부사 시작", r"^\s*(또한|게다가|더불어|아울러|나아가|한편|따라서|그러나|하지만)", "절반은 삭제"),
    ("이모지", r"[\U0001F300-\U0001FAFF☀-➿]", "제거"),
]

ENDING = re.compile(r"(습니다|입니다|합니다|됩니다|한다|이다|였다|았다|었다)\s*[.!?]?\s*$")


def main() -> int:
    for stream in (sys.stdout, sys.stdin):
        try:
            stream.reconfigure(encoding="utf-8")  # Windows consoles default to cp949
        except (AttributeError, ValueError):
            pass

    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8") as fh:
            lines = fh.read().splitlines()
        source = sys.argv[1]
    else:
        lines = sys.stdin.read().splitlines()
        source = "stdin"

    hits = defaultdict(list)
    in_code = False

    for num, line in enumerate(lines, 1):
        if line.lstrip().startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        for category, pattern, note in PATTERNS:
            for m in re.finditer(pattern, line, re.MULTILINE):
                hits[(category, note)].append((num, m.group(0)))

    # repeated sentence endings
    endings = []
    for num, line in enumerate(lines, 1):
        for sent in re.split(r"(?<=[.!?])\s+", line):
            m = ENDING.search(sent.strip())
            if m:
                endings.append((num, m.group(1)))
    runs = []
    streak = 1
    for i in range(1, len(endings)):
        if endings[i][1] == endings[i - 1][1]:
            streak += 1
        else:
            if streak >= 3:
                runs.append((endings[i - 1][0], endings[i - 1][1], streak))
            streak = 1
    if streak >= 3 and endings:
        runs.append((endings[-1][0], endings[-1][1], streak))

    print(f"== {source} ==")
    if not hits and not runs:
        print("클리셰 후보 없음. 리듬과 구조는 직접 확인할 것.")
        return 0

    total = 0
    for (category, note), found in sorted(hits.items(), key=lambda kv: -len(kv[1])):
        total += len(found)
        shown = ", ".join(f"L{n}:{t}" for n, t in found[:8])
        more = f" (+{len(found) - 8})" if len(found) > 8 else ""
        print(f"\n[{category}] {len(found)}건 — {note}")
        print(f"  {shown}{more}")

    if runs:
        print(f"\n[어미 반복] {len(runs)}곳 — 서술어 형태 섞기")
        for line_no, ending, count in runs[:8]:
            print(f"  ~L{line_no}: '{ending}' {count}회 연속")

    print(f"\n총 {total}건. 실제로 어색한 것만 고칠 것.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
