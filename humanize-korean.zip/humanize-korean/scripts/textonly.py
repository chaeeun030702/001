#!/usr/bin/env python3
"""Edit only the text of .hwpx / .docx / .pptx files, never the formatting.

    python textonly.py extract  원본.hwpx  segments.json
    (segments.json 의 "text" 값만 고친다)
    python textonly.py apply    원본.hwpx  segments.json  교정본.hwpx
    python textonly.py verify   원본.hwpx  교정본.hwpx

extract  본문 XML의 텍스트 조각(segment)을 문단별로 JSON에 뽑는다.
apply    원본 zip을 항목 순서·압축 방식 그대로 복사하면서, 바뀐 텍스트 조각의
         문자만 원본 XML 문자열 안에서 교체한다. XML을 파싱해 다시 저장하지 않으므로
         글꼴·크기·굵기·색·스타일 참조·이미지·header 등은 바이트 단위로 유지된다.
         HWPX는 텍스트가 바뀐 문단의 <hp:linesegarray>만 지워 줄 배치를 다시 계산하게 한다.
verify   두 파일을 비교해 텍스트 외의 차이가 있으면 목록을 출력하고 종료 코드 1을 돌려준다.
"""

import html
import json
import re
import sys
import zipfile
from xml.sax.saxutils import escape

FORMATS = {
    "hwpx": dict(p="hp:p", r="hp:run", t="hp:t", lineseg="hp:linesegarray",
                 parts=re.compile(r"^Contents/section\d+\.xml$")),
    "docx": dict(p="w:p", r="w:r", t="w:t", lineseg=None,
                 parts=re.compile(r"^word/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml$")),
    "pptx": dict(p="a:p", r="a:r", t="a:t", lineseg=None,
                 parts=re.compile(r"^ppt/(slides/slide|notesSlides/notesSlide)\d+\.xml$")),
}
TAG = re.compile(r"<(/?)([A-Za-z_][\w.-]*:?[\w.-]*)([^>]*?)(/?)>|<\?[^>]*\?>|<!--.*?-->", re.S)


def fmt_of(path):
    ext = path.rsplit(".", 1)[-1].lower()
    if ext not in FORMATS:
        sys.exit(f"지원하지 않는 형식: .{ext} (hwpx, docx, pptx만 가능)")
    return ext, FORMATS[ext]


def scan(xml, f):
    """Return (segments, paragraphs, linesegs).

    segments: [{start, end, para, run_attrs, run_raw}]  -- text chunk spans inside <t>
    linesegs: [(start, end, para)]                       -- HWPX line layout caches
    """
    segs, linesegs = [], []
    pstack, para_count = [], 0
    in_t = 0
    run_attrs, run_start = "", 0
    ls_start = None
    last_end = 0
    for m in TAG.finditer(xml):
        if in_t and m.start() > last_end:
            segs.append(dict(start=last_end, end=m.start(), para=pstack[-1] if pstack else -1,
                             run_attrs=run_attrs, run_raw=xml[run_start:m.start()]))
        last_end = m.end()
        close, name, attrs, selfclose = m.group(1), m.group(2), m.group(3), m.group(4)
        if name is None:
            continue
        if name == f["p"]:
            if close:
                pstack.pop()
            elif not selfclose:
                pstack.append(para_count)
                para_count += 1
        elif name == f["r"] and not close:
            run_attrs, run_start = attrs or "", m.start()
        elif name == f["t"] and not selfclose:
            in_t += -1 if close else 1
        elif f["lineseg"] and name == f["lineseg"]:
            if selfclose:
                linesegs.append((m.start(), m.end(), pstack[-1] if pstack else -1))
            elif close and ls_start is not None:
                linesegs.append((ls_start, m.end(), pstack[-1] if pstack else -1))
                ls_start = None
            else:
                ls_start = m.start()
    return segs, linesegs


def char_props(z):
    """HWPX charPr id -> (pt size, bold)."""
    try:
        h = z.read("Contents/header.xml").decode("utf-8")
    except KeyError:
        return {}
    out = {}
    for i, body in re.findall(r'<hh:charPr id="(\d+)"(.*?)</hh:charPr>', h, re.S):
        size = re.search(r'height="(\d+)"', body)
        out[i] = (int(size.group(1)) / 100 if size else None, "<hh:bold" in body)
    return out


def describe(ext, seg, cprops):
    if ext == "hwpx":
        m = re.search(r'charPrIDRef="(\d+)"', seg["run_attrs"])
        if m and m.group(1) in cprops:
            size, bold = cprops[m.group(1)]
            return f"{size:g}pt" + (" 굵게" if bold else "")
        return ""
    raw = seg["run_raw"]
    if ext == "docx":
        return "굵게" if re.search(r'<w:b(\s(?![^>]*w:val="(0|false)")[^>]*)?/>', raw) else ""
    return "굵게" if re.search(r'<a:rPr[^>]*\sb="(1|true)"', raw) else ""


def body_parts(z, f):
    return [n for n in z.namelist() if f["parts"].match(n)]


def extract(src, out):
    ext, f = fmt_of(src)
    with zipfile.ZipFile(src) as z:
        cprops = char_props(z) if ext == "hwpx" else {}
        result = {"source": src, "note": "text 값만 고친다. 조각을 추가·삭제하거나 id를 바꾸지 않는다. "
                  "서식이 다른 조각 사이로 글자를 옮기지 않는다. 지우려면 빈 문자열로 둔다.", "parts": {}}
        total = 0
        for part in body_parts(z, f):
            xml = z.read(part).decode("utf-8")
            segs, _ = scan(xml, f)
            paras = {}
            for i, s in enumerate(segs):
                item = {"id": i, "text": html.unescape(xml[s["start"]:s["end"]])}
                d = describe(ext, s, cprops)
                if d:
                    item["fmt"] = d
                paras.setdefault(s["para"], []).append(item)
            result["parts"][part] = [{"p": p, "segs": v} for p, v in paras.items()]
            total += len(segs)
    with open(out, "w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=1)
    print(f"{total}개 텍스트 조각 → {out}")


def apply(src, seg_json, dst):
    ext, f = fmt_of(src)
    edits = json.load(open(seg_json, encoding="utf-8"))["parts"]
    changed_total = 0
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, "w") as zout:
        parts = set(body_parts(zin, f))
        for info in zin.infolist():
            data = zin.read(info.filename)
            if info.filename in parts and info.filename in edits:
                xml = data.decode("utf-8")
                segs, linesegs = scan(xml, f)
                new = {s["id"]: s["text"] for p in edits[info.filename] for s in p["segs"]}
                if set(new) != set(range(len(segs))):
                    sys.exit(f"{info.filename}: 조각 id가 원본과 다르다 (추가·삭제 금지). 다시 extract 하라.")
                cuts, dirty = [], set()
                for i, s in enumerate(segs):
                    old_raw = xml[s["start"]:s["end"]]
                    if new[i] != html.unescape(old_raw):
                        if ext == "docx" and new[i] != new[i].strip() and "xml:space" not in s["run_raw"][-200:]:
                            print(f"경고: {info.filename} 조각 {i} 앞뒤 공백이 Word에서 사라질 수 있음")
                        cuts.append((s["start"], s["end"], escape(new[i])))
                        dirty.add(s["para"])
                cuts += [(a, b, "") for a, b, p in linesegs if p in dirty]
                for a, b, rep in sorted(cuts, reverse=True):
                    xml = xml[:a] + rep + xml[b:]
                changed_total += len(dirty)
                data = xml.encode("utf-8")
            zout.writestr(info, data, compress_type=info.compress_type)
    print(f"텍스트가 바뀐 문단 {changed_total}개 → {dst}")
    return verify(src, dst)


def skeleton(xml, f):
    segs, linesegs = scan(xml, f)
    cuts = [(s["start"], s["end"]) for s in segs] + [(a, b) for a, b, _ in linesegs]
    for a, b in sorted(cuts, reverse=True):
        xml = xml[:a] + xml[b:]
    return xml


def verify(orig, edited):
    ext, f = fmt_of(orig)
    problems = []
    with zipfile.ZipFile(orig) as a, zipfile.ZipFile(edited) as b:
        na, nb = a.namelist(), b.namelist()
        if na != nb:
            problems.append(f"zip 항목 목록·순서가 다름: 추가 {sorted(set(nb) - set(na))}, 빠짐 {sorted(set(na) - set(nb))}")
        parts = set(body_parts(a, f))
        for info in a.infolist():
            n = info.filename
            if n not in nb:
                continue
            if b.getinfo(n).compress_type != info.compress_type:
                problems.append(f"{n}: 압축 방식이 다름")
            da, db = a.read(n), b.read(n)
            if da == db:
                continue
            if n in parts:
                if skeleton(da.decode("utf-8"), f) != skeleton(db.decode("utf-8"), f):
                    problems.append(f"{n}: 텍스트 외 서식·구조(문단·런·속성·참조)가 바뀜")
            else:
                problems.append(f"{n}: 본문이 아닌 파트가 바뀜 (글꼴·스타일·이미지 등)")
    if problems:
        print("검증 실패 — 텍스트 외 변경:")
        for p in problems:
            print("  -", p)
        return 1
    print("검증 통과 — 텍스트 외 변경 없음")
    return 0


def main():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    cmds = {"extract": (extract, 2), "apply": (apply, 3), "verify": (verify, 2)}
    if len(sys.argv) < 2 or sys.argv[1] not in cmds or len(sys.argv) != cmds[sys.argv[1]][1] + 2:
        sys.exit(__doc__)
    fn, _ = cmds[sys.argv[1]]
    return fn(*sys.argv[2:]) or 0


if __name__ == "__main__":
    sys.exit(main())
